# Scholar Voice — Android App

PDF text-to-speech reader for Android. Import any PDF and have it read aloud with speed control, voice selection, and reading progress tracking.

## Features
- 📄 Import PDFs from storage or open directly from other apps
- 🔊 Text-to-speech with all device voices
- ⚡ Speed control: 0.5× to 3× with presets
- ⏭ Skip forward/back by 3 sentences
- 📊 Progress bar, sentence counter, time remaining
- 🕘 Recent files list

## Build Instructions

### Requirements
- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 34
- Java 11+

### Steps
1. Open Android Studio
2. File → Open → select this `ScholarVoice` folder
3. Wait for Gradle sync (first time downloads dependencies, ~2 min)
4. Connect Android phone with USB Debugging enabled
   - Settings → About Phone → tap "Build Number" 7 times → Developer Options → USB Debugging
5. Select your device in the toolbar
6. Click ▶ Run (or Shift+F10)

### Build APK without a device
- Build → Build Bundle(s)/APK(s) → Build APK(s)
- APK will be at: `app/build/outputs/apk/debug/app-debug.apk`
- Transfer to phone and install (allow "Install unknown apps" in settings)

## Minimum Android version: 7.0 (API 24)
