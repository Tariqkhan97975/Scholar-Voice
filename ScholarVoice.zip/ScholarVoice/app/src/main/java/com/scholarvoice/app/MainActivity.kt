package com.scholarvoice.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.scholarvoice.app.databinding.ActivityMainBinding
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val recentFiles = mutableListOf<RecentFile>()
    private lateinit var adapter: RecentFilesAdapter

    data class RecentFile(val name: String, val uri: String, val timestamp: Long)

    private val pickPdf = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { openPdf(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        loadRecentFiles()

        binding.btnImport.setOnClickListener { pickPdf.launch("application/pdf") }
        binding.btnClearRecent.setOnClickListener { clearRecentFiles() }

        // Handle PDF opened from another app
        if (intent?.action == Intent.ACTION_VIEW && intent.data != null) {
            openPdf(intent.data!!)
        }
    }

    private fun setupRecyclerView() {
        adapter = RecentFilesAdapter(recentFiles) { file ->
            try {
                openPdf(Uri.parse(file.uri))
            } catch (e: Exception) {
                removeRecentFile(file)
                binding.tvEmptyState.visibility = if (recentFiles.isEmpty()) View.VISIBLE else View.GONE
            }
        }
        binding.recyclerRecent.layoutManager = LinearLayoutManager(this)
        binding.recyclerRecent.adapter = adapter
    }

    private fun openPdf(uri: Uri) {
        // Persist URI permission
        try {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {}

        val name = getFileName(uri)
        saveRecentFile(name, uri)

        val intent = Intent(this, ReaderActivity::class.java).apply {
            putExtra("pdf_uri", uri.toString())
            putExtra("pdf_name", name)
        }
        startActivity(intent)
    }

    private fun getFileName(uri: Uri): String {
        var name = "Unknown PDF"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && idx >= 0) name = cursor.getString(idx)
        }
        return name
    }

    private fun saveRecentFile(name: String, uri: Uri) {
        val existing = recentFiles.indexOfFirst { it.uri == uri.toString() }
        if (existing >= 0) recentFiles.removeAt(existing)
        recentFiles.add(0, RecentFile(name, uri.toString(), System.currentTimeMillis()))
        if (recentFiles.size > 20) recentFiles.removeAt(recentFiles.size - 1)
        persistRecentFiles()
        adapter.notifyDataSetChanged()
        binding.tvEmptyState.visibility = View.GONE
        binding.btnClearRecent.visibility = View.VISIBLE
    }

    private fun removeRecentFile(file: RecentFile) {
        recentFiles.remove(file)
        persistRecentFiles()
        adapter.notifyDataSetChanged()
    }

    private fun clearRecentFiles() {
        recentFiles.clear()
        persistRecentFiles()
        adapter.notifyDataSetChanged()
        binding.tvEmptyState.visibility = View.VISIBLE
        binding.btnClearRecent.visibility = View.GONE
    }

    private fun persistRecentFiles() {
        val prefs = getSharedPreferences("scholar_voice", MODE_PRIVATE)
        val arr = JSONArray()
        recentFiles.forEach { f ->
            val obj = JSONObject()
            obj.put("name", f.name)
            obj.put("uri", f.uri)
            obj.put("ts", f.timestamp)
            arr.put(obj)
        }
        prefs.edit().putString("recent_files", arr.toString()).apply()
    }

    private fun loadRecentFiles() {
        val prefs = getSharedPreferences("scholar_voice", MODE_PRIVATE)
        val json = prefs.getString("recent_files", "[]") ?: "[]"
        try {
            val arr = JSONArray(json)
            recentFiles.clear()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                recentFiles.add(RecentFile(obj.getString("name"), obj.getString("uri"), obj.getLong("ts")))
            }
        } catch (_: Exception) {}
        adapter.notifyDataSetChanged()
        binding.tvEmptyState.visibility = if (recentFiles.isEmpty()) View.VISIBLE else View.GONE
        binding.btnClearRecent.visibility = if (recentFiles.isEmpty()) View.GONE else View.VISIBLE
    }
}

class RecentFilesAdapter(
    private val files: List<MainActivity.RecentFile>,
    private val onClick: (MainActivity.RecentFile) -> Unit
) : RecyclerView.Adapter<RecentFilesAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tv_file_name)
        val tvDate: TextView = view.findViewById(R.id.tv_file_date)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_recent_file, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val file = files[position]
        holder.tvName.text = file.name
        holder.tvDate.text = formatTime(file.timestamp)
        holder.itemView.setOnClickListener { onClick(file) }
    }

    override fun getItemCount() = files.size

    private fun formatTime(ts: Long): String {
        val now = System.currentTimeMillis()
        val diff = now - ts
        return when {
            diff < 60_000 -> "Just now"
            diff < 3_600_000 -> "${diff / 60_000}m ago"
            diff < 86_400_000 -> "${diff / 3_600_000}h ago"
            else -> "${diff / 86_400_000}d ago"
        }
    }
}
