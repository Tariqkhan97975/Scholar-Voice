package com.scholarvoice.app

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.IOException

object PDFExtractor {

    private var initialized = false

    fun extractText(context: Context, uri: Uri): String? {
        // Initialize PDFBox once
        if (!initialized) {
            PDFBoxResourceLoader.init(context.applicationContext)
            initialized = true
        }

        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val doc = PDDocument.load(stream)
                val stripper = PDFTextStripper()
                stripper.sortByPosition = true
                stripper.addMoreFormatting = true
                val text = stripper.getText(doc)
                doc.close()
                text.trim().takeIf { it.isNotBlank() }
            }
        } catch (e: IOException) {
            null
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Extract text page by page (for large PDFs, shows progress).
     */
    fun extractTextPaged(
        context: Context,
        uri: Uri,
        onPage: (page: Int, total: Int, text: String) -> Unit
    ): String? {
        if (!initialized) {
            PDFBoxResourceLoader.init(context.applicationContext)
            initialized = true
        }

        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val doc = PDDocument.load(stream)
                val total = doc.numberOfPages
                val sb = StringBuilder()
                val stripper = PDFTextStripper()
                stripper.sortByPosition = true

                for (i in 1..total) {
                    stripper.startPage = i
                    stripper.endPage = i
                    val pageText = stripper.getText(doc)
                    sb.append(pageText).append("\n")
                    onPage(i, total, pageText)
                }

                doc.close()
                sb.toString().trim().takeIf { it.isNotBlank() }
            }
        } catch (e: Exception) {
            null
        }
    }
}
