package com.scholarvoice.app

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri
import androidx.lifecycle.lifecycleScope
import com.scholarvoice.app.databinding.ActivityReaderBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.min

class ReaderActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var binding: ActivityReaderBinding
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private var sentences = listOf<String>()
    private var currentIdx = 0
    private var isPlaying = false
    private var isPaused = false
    private var speed = 1.0f
    private var selectedVoice: android.speech.tts.Voice? = null
    private var totalWords = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReaderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val uri = intent.getStringExtra("pdf_uri") ?: run { finish(); return }
        val name = intent.getStringExtra("pdf_name") ?: "PDF"

        binding.tvTitle.text = name
        binding.btnBack.setOnClickListener { finish() }

        tts = TextToSpeech(this, this)
        loadPreferences()
        setupControls()
        extractAndLoad(uri)
    }

    // ── TTS Init ──────────────────────────────────────────────────────────
    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            showStatus("TTS engine unavailable")
            return
        }
        tts?.language = Locale.US
        ttsReady = true
        populateVoices()
    }

    private fun populateVoices() {
        val voices = tts?.voices
            ?.filter { it.locale.language == "en" && !it.isNetworkConnectionRequired }
            ?.sortedWith(compareBy({ !it.name.contains("network", true) }, { it.name }))
            ?.toMutableList() ?: mutableListOf()

        val names = mutableListOf("Auto (Best Available)") + voices.map { it.name }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, names)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerVoice.adapter = adapter

        // Restore saved voice
        val prefs = getSharedPreferences("scholar_voice", MODE_PRIVATE)
        val saved = prefs.getString("voice_name", "")
        val idx = voices.indexOfFirst { it.name == saved }
        if (idx >= 0) binding.spinnerVoice.setSelection(idx + 1)

        binding.spinnerVoice.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                selectedVoice = if (pos == 0) null else voices.getOrNull(pos - 1)
                selectedVoice?.let { tts?.voice = it }
                val voiceName = selectedVoice?.name ?: ""
                getSharedPreferences("scholar_voice", MODE_PRIVATE).edit()
                    .putString("voice_name", voiceName).apply()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    // ── PDF Loading ────────────────────────────────────────────────────────
    private fun extractAndLoad(uriString: String) {
        binding.progressLoading.visibility = View.VISIBLE
        binding.layoutControls.visibility = View.GONE
        binding.tvStatus.text = "Extracting text…"

        lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) {
                PDFExtractor.extractText(this@ReaderActivity, uriString.toUri())
            }

            binding.progressLoading.visibility = View.GONE

            if (text.isNullOrBlank()) {
                binding.tvStatus.text = "Could not extract text from this PDF."
                return@launch
            }

            sentences = splitSentences(cleanText(text))
            totalWords = text.split(Regex("\\s+")).size

            binding.layoutControls.visibility = View.VISIBLE
            updateProgress()
            showStatus("Ready · ${sentences.size} sentences · ~${totalWords.toLong().toReadableWords()}")
        }
    }

    private fun cleanText(text: String): String = text
        .replace(Regex("\\s+"), " ")
        .replace(Regex("\\[\\d+(,\\s*\\d+)*]"), "")
        .replace("et al.", "et al")
        .replace("i.e.", "that is")
        .replace("e.g.", "for example")
        .replace("vs.", "versus")
        .replace("Fig.", "Figure")
        .replace("Eq.", "Equation")
        .trim()

    private fun splitSentences(text: String): List<String> {
        val raw = text.split(Regex("(?<=[.!?])\\s+(?=[A-Z\"'(])"))
        val chunks = mutableListOf<String>()
        var acc = ""
        for (part in raw) {
            acc += if (acc.isEmpty()) part else " $part"
            if (acc.length >= 200) { chunks.add(acc.trim()); acc = "" }
        }
        if (acc.isNotBlank()) chunks.add(acc.trim())
        return chunks.filter { it.length > 3 && it.any { c -> c.isLetter() } }
    }

    // ── Controls Setup ─────────────────────────────────────────────────────
    private fun setupControls() {
        binding.btnPlayPause.setOnClickListener {
            when {
                !isPlaying && !isPaused -> startReading()
                isPlaying -> pauseReading()
                isPaused -> resumeReading()
            }
        }

        binding.btnStop.setOnClickListener { stopReading() }
        binding.btnRestart.setOnClickListener { stopReading(); currentIdx = 0; startReading() }

        binding.btnPrev.setOnClickListener {
            val was = isPlaying
            stopReading()
            currentIdx = maxOf(0, currentIdx - 3)
            updateProgress()
            if (was) startReading()
        }

        binding.btnNext.setOnClickListener {
            val was = isPlaying
            stopReading()
            currentIdx = minOf(sentences.size - 1, currentIdx + 3)
            updateProgress()
            if (was) startReading()
        }

        // Speed presets
        listOf(
            binding.btn075x to 0.75f,
            binding.btn100x to 1.0f,
            binding.btn125x to 1.25f,
            binding.btn150x to 1.5f,
            binding.btn200x to 2.0f
        ).forEach { (btn, s) ->
            btn.setOnClickListener { setSpeed(s) }
        }

        binding.sliderSpeed.addOnChangeListener { _, value, fromUser ->
            if (fromUser) setSpeed(value)
        }

        updateSpeedUI()
    }

    // ── Playback ──────────────────────────────────────────────────────────
    private fun startReading() {
        if (!ttsReady || sentences.isEmpty()) return
        isPlaying = true
        isPaused = false
        updatePlayPauseBtn()
        speakFrom(currentIdx)
    }

    private fun pauseReading() {
        tts?.stop()
        isPaused = true
        isPlaying = false
        updatePlayPauseBtn()
    }

    private fun resumeReading() {
        isPaused = false
        isPlaying = true
        updatePlayPauseBtn()
        speakFrom(currentIdx)
    }

    private fun stopReading() {
        tts?.stop()
        isPlaying = false
        isPaused = false
        updatePlayPauseBtn()
    }

    private fun speakFrom(idx: Int) {
        if (idx >= sentences.size || !isPlaying) {
            isPlaying = false
            isPaused = false
            runOnUiThread { updatePlayPauseBtn(); showStatus("Done") }
            return
        }
        currentIdx = idx
        val text = sentences[idx]

        runOnUiThread {
            updateProgress()
            val preview = text.split(" ").take(5).joinToString(" ") + "…"
            binding.tvNowReading.text = preview
        }

        val params = Bundle()
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        tts?.setSpeechRate(speed)
        selectedVoice?.let { tts?.voice = it }

        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (isPlaying && !isPaused) speakFrom(idx + 1)
            }
            override fun onError(utteranceId: String?) {
                speakFrom(idx + 1)
            }
        })

        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "sv_$idx")
    }

    // ── UI Helpers ─────────────────────────────────────────────────────────
    private fun updatePlayPauseBtn() {
        binding.btnPlayPause.setImageResource(
            if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
        )
    }

    private fun updateProgress() {
        if (sentences.isEmpty()) return
        val pct = currentIdx.toFloat() / sentences.size
        val pctInt = (pct * 100).toInt()
        binding.progressBar.progress = pctInt
        binding.tvProgress.text = "$pctInt%"
        binding.tvSentenceCount.text = "${currentIdx + 1} / ${sentences.size}"
        val wordsLeft = (sentences.drop(currentIdx).sumOf { it.split(" ").size })
        val wpm = (speed * 150).toInt()
        val minsLeft = wordsLeft / wpm
        binding.tvTimeLeft.text = if (minsLeft < 1) "<1 min left" else "$minsLeft min left"
    }

    private fun showStatus(msg: String) {
        binding.tvStatus.text = msg
    }

    private fun setSpeed(s: Float) {
        speed = s
        binding.sliderSpeed.value = s
        updateSpeedUI()
        getSharedPreferences("scholar_voice", MODE_PRIVATE).edit().putFloat("speed", s).apply()
        if (isPlaying) { stopReading(); startReading() }
    }

    private fun updateSpeedUI() {
        binding.tvSpeedValue.text = "${speed}×"
        listOf(
            binding.btn075x to 0.75f,
            binding.btn100x to 1.0f,
            binding.btn125x to 1.25f,
            binding.btn150x to 1.5f,
            binding.btn200x to 2.0f
        ).forEach { (btn, s) ->
            btn.isSelected = s == speed
        }
    }

    private fun loadPreferences() {
        val prefs = getSharedPreferences("scholar_voice", MODE_PRIVATE)
        speed = prefs.getFloat("speed", 1.0f)
        binding.sliderSpeed.value = speed
    }

    private fun Long.toReadableWords(): String = when {
        this < 1000 -> "$this words"
        else -> String.format("%.1fk words", this / 1000.0)
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
